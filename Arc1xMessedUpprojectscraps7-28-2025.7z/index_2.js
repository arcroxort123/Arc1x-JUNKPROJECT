const express = require('express');
    const sqlite3 = require('sqlite3');
    const winston = require('winston');
    const dotenv = require('dotenv');

    dotenv.config();

    const app = express();
    const db = new sqlite3.Database('./database.db');

    // Logging middleware
    const logger = winston.createLogger({
      level: 'info',
      format: winston.format.combine(
        winston.format.timestamp(),
        winston.format.printf(({ level, message }) => {
          return `[${level}] ${message}`;
        })
      ),
      transports: [
        new winston.transports.Console(),
        new winston.transports.File({ filename: 'logs/app.log' })
      ]
    });

    // Routes
    app.get('/', (req, res) => {
      logger.info('Root route accessed');
      res.send('Server System - REST API');
    });

    app.get('/api/data', (req, res) => {
      logger.info('GET /api/data called');
      res.json({ message: 'Data retrieved' });
    });

    app.post('/api/data', (req, res) => {
      logger.info('POST /api/data called');
      const { name, value } = req.body;
      logger.info(`Received data: ${name}=${value}`);
      
      db.run(`INSERT INTO data (name, value) VALUES (?, ?)`, [name, value], (err) => {
        if (err) {
          logger.error(`Failed to insert data: ${err.message}`);
          return res.status(500).json({ error: 'Internal server error' });
        }
        logger.info('Data inserted successfully');
        res.status(201).json({ message: 'Data added' });
      });
    });

    // Error handling
    app.use((req, res, next) => {
      logger.error('Unhandled route');
      res.status(404).json({ error: 'Not found' });
    });

    app.listen(3000, () => {
      logger.info('Server running on http://localhost:3000');
    });
