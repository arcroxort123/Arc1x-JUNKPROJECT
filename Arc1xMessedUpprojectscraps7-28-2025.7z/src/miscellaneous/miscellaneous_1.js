{
      "name": "miscellaneous",
      "type": "object",
      "value": {
        "misc": {
          "build": "Run 'npm run build' for production",
          "deploy": "Use 'npm run dev' for development",
          "debug": "Set environment variable 'DEBUG=*' for detailed logs"
        }
      }
    }
