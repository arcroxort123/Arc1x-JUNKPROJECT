const express = require('express');
    const router = express.Router();

    router.get('/policies', (req, res) => {
      res.send('Secure policies and conditions for code builds');
    });

    module.exports = router;
