const express = require('express');
    const router = express.Router();

    router.get('/permissions', (req, res) => {
      res.send('Secure permissions for Arc1xServerOS system');
    });

    module.exports = router;
