const express = require('express');
    const router = express.Router();

    router.get('/vm', (req, res) => {
      res.send('Secure VM access with AI protection and encryption');
    });

    module.exports = router;
