const express = require('express');
    const router = express.Router();

    router.get('/permissions', (req, res) => {
      res.send('Secure permissions and role-based access control');
    });

    module.exports = router;
