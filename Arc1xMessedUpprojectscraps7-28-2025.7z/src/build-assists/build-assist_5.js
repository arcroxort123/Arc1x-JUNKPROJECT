make a project for my code or additional options for sub-modules: make a project for my code or additional options for sub-modules: make a project for my code or additional options for sub-modules: 

