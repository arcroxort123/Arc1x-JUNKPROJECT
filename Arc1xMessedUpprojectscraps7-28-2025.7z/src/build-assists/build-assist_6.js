{
      "name": "build-assist",
      "type": "object",
      "value": {
        "scripts": {
          "lint": "tsc --noEmit --watch",
          "test": "jest",
          "build": "tsc && webpack --mode production"
        },
        "environment": {
          "NODE_ENV": "production"
        }
      }
    }
