{
      "name": "protocols",
      "type": "object",
      "value": {
        "http": {
          "headers": {
            "Content-Type": "application/json"
          },
          "methods": {
            "GET": "Retrieve data",
            "POST": "Create data"
          }
        },
        "websocket": {
          "headers": {
            "Sec-WebSocket-Protocol": "application/json"
          },
          "methods": {
            "OPEN": "Establish connection",
            "CLOSE": "Close connection"
          }
        }
      }
    }
