{
      "name": "config",
      "type": "object",
      "value": {
        "default": {
          "port": 3001,
          "logLevel": "info",
          "secure": true,
          "troubleshoot": {
            "timeout": 30000,
            "retry": 3
          },
          "build": {
            "mode": "production",
            "optimize": true
          }
        }
      }
    }
