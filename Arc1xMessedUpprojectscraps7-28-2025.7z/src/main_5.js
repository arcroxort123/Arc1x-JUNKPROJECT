const express = require('express');
    const db = require('./database');
    const app = express();

    // Routes
    app.get('/', (req, res) => {
      res.send('AutoCode Engine - Real-Time Projections & Immersive After-Effects');
    });

    // Database
    app.get('/api/data', (req, res) => {
      db.all('SELECT * FROM projections', (err, rows) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json(rows);
      });
    });

    // Interactive Shell
    app.get('/api/interactive', (req, res) => {
      res.json({ message: 'Interactive shell for real-time projections' });
    });

    // After-Effects Integration
    app.get('/api/aftereffects', (req, res) {
      res.json({ message: 'Immersive After-Effects rendering pipeline' });
    });

    // Start server
    app.listen(3001, () => {
      console.log('Server running on http://localhost:3001');
    });
