const express = require('express');
    const router = express.Router();
    const db = require('./database');

    // Monitoring Data
    router.get('/api/monitor', (req, res) => {
      db.all('SELECT * FROM monitoring_data', (err, rows) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json(rows);
      });
    });

    // HyperMilling Exports
    router.get('/api/exports', (req, res) => {
      db.all('SELECT * FROM hypermilling_exports', (err, rows) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json(rows);
      });
    });

    // VR Environments
    router.get('/api/vr', (req, res) => {
      db.all('SELECT * FROM vr_environments', (err, rows) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json(rows);
      });
    });

    // AiCloudworks
    router.get('/api/ai-cloudworks', (req, res) => {
      db.all('SELECT * FROM ai_cloudworks', (err, rows) => {
        if (err) return res.status(500).json({ error: 'Database error' });
        res.json(rows);
      });
    });

    module.exports = router;
