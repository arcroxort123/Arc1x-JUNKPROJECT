const db = require('sqlite3');
    const database = db.open('./database.db');

    module.exports = {
      query: (sql, params) => database.run(sql, params),
      get: (sql, params) => database.get(sql, params)
    };
