// Cluster/Cloister Assignment Transfer Module
    // Supports FlashOver and Preload/AfterProduct logic

    import React from 'react';
    import ReactDOM from 'react-dom';
    import { simulateFlashOver } from './flash-over';
    import { checkPreloadAfterProduct } from './preload-after-product';

    function TransferManager() {
      const [isFlashOver, setIsFlashOver] = React.useState(false);
      const [isPreloadAfterProduct, setIsPreloadAfterProduct] = React.useState(false);

      React.useEffect(() => {
        simulateFlashOver();
        checkPreloadAfterProduct();
      }, []);

      return (
        <div>
          <h1>Cluster/Cloister Transfer Manager</h1>
          <div>
            <h2>FlashOver Status</h2>
            <p>FlashOver Enabled: {isFlashOver ? 'Yes' : 'No'}</p>
            <button onClick={() => setIsFlashOver(!isFlashOver)}>Toggle FlashOver</button>
          </div>
          <div>
            <h2>Preload/AfterProduct Status</h2>
            <p>Preload/AfterProduct Enabled: {isPreloadAfterProduct ? 'Yes' : 'No'}</p>
            <button onClick={() => setIsPreloadAfterProduct(!isPreloadAfterProduct)}>Toggle Preload/AfterProduct</button>
          </div>
        </div>
      );
    }

    ReactDOM.render(<TransferManager />, document.getElementById('root'));
