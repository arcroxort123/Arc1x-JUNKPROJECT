// ThirdParty-VrEnv-FullDive-EZ-Ext Logic
    console.log("ThirdParty-VrEnv-FullDive-EZ-Ext: Initializing virtual reality environment...");
