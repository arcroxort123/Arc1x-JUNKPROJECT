// Project root directory
    console.log("08-Arc1x-Policy-Conditions Public - Expanded Structure with Explanations");
