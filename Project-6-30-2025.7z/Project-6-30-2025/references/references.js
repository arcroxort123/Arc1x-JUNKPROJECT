// References
    console.log("References: Documentation and resources for the project");
