// Protocols
    console.log("Protocols: Communication and data transfer standards");
