// Configurations
    console.log("Configurations: Setup and build parameters");
