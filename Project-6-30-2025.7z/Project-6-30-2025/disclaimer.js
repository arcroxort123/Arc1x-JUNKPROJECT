// Simple disclaimer script
    console.log("Disclaimer: Don't Read this unless you want to Rip Me Off then Go Ahead. I don't care cuz I made it all up.");
