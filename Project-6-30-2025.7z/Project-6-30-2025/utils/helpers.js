// Helper functions
    function isSecureConnection(req) {
      return req.headers['x-forwarded-for'] && req.headers['x-forwarded-for'].split(',')[0] === '127.0.0.1';
    }
