// Utility functions
    function formatDate(date) {
      return new Date(date).toLocaleString();
    }
