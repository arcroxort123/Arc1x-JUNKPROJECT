// VR Environment setup
    const fs = require('fs');
    const path = require('path');

    async function processVREnvironment(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing VR environment file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'vr-env.txt');
    await processVREnvironment(filePath);
