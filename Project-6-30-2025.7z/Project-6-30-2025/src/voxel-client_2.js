// Voxel client setup
    const fs = require('fs');
    const path = require('path');

    async function processVoxelClient(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing voxel client file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'voxel-client.txt');
    await processVoxelClient(filePath);
