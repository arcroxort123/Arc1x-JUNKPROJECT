// Basic network setup
    const net = require('net');

    const server = net.createServer((socket) => {
      socket.on('data', (data) => {
        console.log(`Received data: ${data}`);
      });
      socket.end();
    });

    server.listen(3001, () => {
      console.log('Server is listening on port 3001');
    });
