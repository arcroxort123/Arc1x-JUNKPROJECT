// Arc1xKernal setup
    const fs = require('fs');
    const path = require('path');

    async function processArc1xKernel(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing arc1x kernel file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'arc1xkernel.txt');
    await processArc1xKernel(filePath);

    // Additional Arc1xKernal functionality can be added here
