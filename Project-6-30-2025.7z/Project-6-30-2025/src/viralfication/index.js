const express = require('express');
    const app = express();
    const port = process.env.PORT || 3000;

    // Secure routes middleware
    function secureRoutes(app) {
      app.use((req, res, next) => {
        console.log(`Request to ${req.url} is secured.`);
        next();
      });
    }

    secureRoutes(app);

    app.get('/', (req, res) => {
      res.send('Semi-Secured (ViralProtection) server is running!');
    });

    app.listen(port, () => {
      console.log(`Semi-Secured (ViralProtection) server is running on http://localhost:${port}`);
    });
