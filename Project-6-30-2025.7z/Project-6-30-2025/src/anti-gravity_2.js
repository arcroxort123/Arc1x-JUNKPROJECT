// Anti-Gravity setup
    const fs = require('fs');
    const path = require('path');

    async function processAntiGravity(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing anti-gravity file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'anti-gravity.txt');
    await processAntiGravity(filePath);

    // Emp setup
    const fsEmp = require('emp');
    const empFilePath = path.resolve(__dirname, '../', 'emp.json');
    const empFileContent = await fsEmp.readFile(empFilePath);
    console.log(`Emp File Content: ${JSON.stringify(empFileContent)}`);

    // Turbine Power setup
    const fsTurbinePower = require('turbine-power');
    const turbinePowerFilePath = path.resolve(__dirname, '../', 'turbine-power.json');
    const turbinePowerFileContent = await fsTurbinePower.readFile(turbinePowerFilePath);
    console.log(`Turbine Power File Content: ${JSON.stringify(turbinePowerFileContent)}`);

    // Echo Chamber setup
    const echoChamberFilePath = path.resolve(__dirname, '../', 'echo-chamber.json');
    const echoChamberFileContent = await fsEmp.readFile(echoChamberFilePath);
    console.log(`Echo Chamber File Content: ${JSON.stringify(echoChamberFileContent)}`);
