// XStaller setup
    const fs = require('fs');
    const path = require('path');

    async function processXStaller(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing xstaller file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'xstaller.txt');
    await processXStaller(filePath);

    // Additional XStaller functionality can be added here
