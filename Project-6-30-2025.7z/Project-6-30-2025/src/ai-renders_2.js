// AI Renders setup
    const fs = require('fs');
    const path = require('path');

    async function processAIReceives(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing AI renders file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'ai-renders.txt');
    await processAIReceives(filePath);
