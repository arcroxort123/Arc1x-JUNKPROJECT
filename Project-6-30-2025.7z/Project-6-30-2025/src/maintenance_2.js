// Maintenance setup
    const fs = require('fs');
    const path = require('path');

    async function processMaintenance(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing maintenance file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'maintenance.txt');
    await processMaintenance(filePath);
