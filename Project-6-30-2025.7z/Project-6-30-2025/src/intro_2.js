// Intro setup
    const fs = require('fs');
    const path = require('path');

    async function processIntro(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing intro file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'intro.txt');
    await processIntro(filePath);

    // Additional Intro functionality can be added here
