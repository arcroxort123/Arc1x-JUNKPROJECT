// Quantum Streaming setup
    const fs = require('fs');
    const path = require('path');

    async function processQuantumStreaming(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing quantum streaming file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'quantum-streaming.txt');
    await processQuantumStreaming(filePath);
