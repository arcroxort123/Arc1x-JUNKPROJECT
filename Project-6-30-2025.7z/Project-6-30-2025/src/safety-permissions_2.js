// Safety and permissions setup
    const fs = require('fs');
    const path = require('path');

    async function processSafetyPermissions(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing safety and permissions file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'safety-permissions.txt');
    await processSafetyPermissions(filePath);
