// References setup
    const fs = require('fs');
    const path = require('path');

    async function processReferences(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing references file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'references.txt');
    await processReferences(filePath);
