const express = require('express');
    const app = express();
    const port = process.env.PORT || 3000;

    // Sample Voxel Data
    const voxelData1 = {
      id: 'voxel-1',
      model: 'ModelA',
      data: { value: 10, status: 'active' }
    };

    const voxelData2 = {
      id: 'voxel-2',
      model: 'ModelB',
      data: { value: 5, status: 'inactive' }
    };

    // Disassembly Function
    function disassembleVoxelData(voxelData) {
      const { id, model, data } = voxelData;
      
      return {
        id,
        model,
        normalData: {
          ...data,
          transformedValue: data.value * 2, // Example transformation
          status: 'transformed'
        }
      };
    }

    // Define a route to handle GET requests for disassembling voxel data
    app.get('/disassemble', (req, res) => {
      const { id } = req.query;
      const voxelData = voxelData1; // Example voxel data

      try {
        const disassembledVoxelData = disassembleVoxelData(voxelData);
        res.json(disassembledVoxelData);
      } catch (error) {
        console.error(error.message);
        res.status(500).json({ error: 'Disassembly failed' });
      }
    });

    // Define a route to handle GET requests for reading VulkanState
    app.get('/read-vulkan-state', (req, res) => {
      const { id } = req.query;
      const voxelData = voxelData1; // Example voxel data

      try {
        const disassembledVoxelData = disassembleVoxelData(voxelData);
        const vulkanState = {
          id: disassembledVoxelData.id,
          model: disassembledVoxelData.model,
          data: disassembledVoxelData.normalData
        };
        
        res.json(vulkanState);
      } catch (error) {
        console.error(error.message);
        res.status(500).json({ error: 'Reading VulkanState failed' });
      }
    });

    // Start the server
    app.listen(port, () => {
      console.log(`Voxel Disassembly is running on http://localhost:${port}`);
    });
