// Bucket Templates setup
    const fs = require('fs');
    const path = require('path');

    async function processBucketTemplates(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing bucket templates file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'bucket-templates.txt');
    await processBucketTemplates(filePath);
