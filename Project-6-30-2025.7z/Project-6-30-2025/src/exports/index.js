const express = require('express');
    const app = express();
    const port = process.env.PORT || 3000;

    // Simple export logic
    app.get('/', (req, res) => {
      res.send('HyperMilling(Exports) is running!');
    });

    app.listen(port, () => {
      console.log(`HyperMilling(Exports) server is running on http://localhost:${port}`);
    });
