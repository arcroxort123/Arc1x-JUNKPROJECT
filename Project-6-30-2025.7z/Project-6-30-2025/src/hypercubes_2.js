// Hypercube Generation setup
    const fs = require('fs');
    const path = require('path');

    async function generateHypercubes(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing hypercube generation file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'hypercubes.txt');
    await generateHypercubes(filePath);

    // Additional Hypercube Generation functionality can be added here
