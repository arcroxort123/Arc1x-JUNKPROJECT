const express = require('express');
    const app = express();
    const port = process.env.PORT || 3000;

    // Simple monitoring logic
    app.get('/', (req, res) => {
      res.send('Ai-Ecology(Monitor) is running!');
    });

    app.listen(port, () => {
      console.log(`Ai-Ecology(Monitor) server is running on http://localhost:${port}`);
    });
