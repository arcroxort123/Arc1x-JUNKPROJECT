// Configurations setup
    const fs = require('fs');
    const path = require('path');

    async function processConfigurations(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing configurations file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'configurations.txt');
    await processConfigurations(filePath);
