const express = require('express');
    const app = express();
    const port = process.env.PORT || 3000;

    // Sample Voxel Data
    const voxelData1 = {
      id: 'voxel-1',
      model: 'ModelA',
      data: { value: 10, status: 'active' }
    };

    const voxelData2 = {
      id: 'voxel-2',
      model: 'ModelB',
      data: { value: 5, status: 'inactive' }
    };

    // Transfer Function
    function transferVoxelData(voxelData) {
      return {
        ...voxelData,
        transformedValue: voxelData.data.value * 2, // Example transformation
        status: 'transformed'
      };
    }

    // Define a route to handle GET requests for transferring voxel data
    app.get('/transfer', (req, res) => {
      const { id } = req.query;
      const voxelData = voxelData1; // Example voxel data

      try {
        const transferredVoxelData = transferVoxelData(voxelData);
        res.json(transferredVoxelData);
      } catch (error) {
        console.error(error.message);
        res.status(500).json({ error: 'Transfer failed' });
      }
    });

    // Define a route to handle GET requests for receiving transferred data back
    app.get('/receive', (req, res) => {
      const { id } = req.query;
      const voxelData = transferVoxelData(voxelData1); // Example voxel data

      try {
        const receivedVoxelData = transferVoxelData(voxelData);
        res.json(receivedVoxelData);
      } catch (error) {
        console.error(error.message);
        res.status(500).json({ error: 'Receiving failed' });
      }
    });

    // Start the server
    app.listen(port, () => {
      console.log(`Voxel Transfer with Vulkan is running on http://localhost:${port}`);
    });
