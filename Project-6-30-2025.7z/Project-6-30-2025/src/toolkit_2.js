// Administration Toolkit setup
    const fs = require('fs');
    const path = require('path');

    async function processToolkit(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing toolkit file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'toolkit.txt');
    await processToolkit(filePath);
