// BuildProcessor setup
    const fs = require('fs');
    const path = require('path');

    async function processBuildProcessor(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing build processor file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'buildprocessor.txt');
    await processBuildProcessor(filePath);

    // Additional BuildProcessor functionality can be added here
