// Image Mount setup
    const fs = require('fs');
    const path = require('path');

    async function processImageMount(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing image mount file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'image-mount.txt');
    await processImageMount(filePath);

    // Additional Image Mount functionality can be added here
