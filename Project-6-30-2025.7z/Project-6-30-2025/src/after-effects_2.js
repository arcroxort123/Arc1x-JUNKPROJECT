// After Effects setup
    const fs = require('fs');
    const path = require('path');

    async function processAfterEffects(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing after effects file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'after-effects.txt');
    await processAfterEffects(filePath);
