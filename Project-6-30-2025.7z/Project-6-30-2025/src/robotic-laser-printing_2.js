// Robotic Laser Printing setup
    const fs = require('fs');
    const path = require('path');

    async function processRoboticLaserPrinting(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing robotic laser printing file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'robotic-laser-printing.txt');
    await processRoboticLaserPrinting(filePath);
