// Matrix Array setup
    const fs = require('fs');
    const path = require('path');

    async function processMatrixArray() {
      try {
        const fileContent = await fs.promises.readFile(path.resolve(__dirname, '../', 'matrix-array.txt'), 'utf-8');
        console.log(fileContent);
        
        // Example matrix array processing
        const matrixData = JSON.parse(fileContent);
        for (let i = 0; i < matrixData.length; i++) {
          for (let j = 0; j < matrixData[i].length; j++) {
            console.log(matrixData[i][j]);
          }
        }
      } catch (error) {
        console.error('Error processing matrix array:', error);
      }
    }

    await processMatrixArray();
