// ToolKit 2 setup
    const fs = require('fs');
    const path = require('path');

    async function processToolkit2(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing toolkit 2 file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'toolkit2.txt');
    await processToolkit2(filePath);
