// ToolKit 1 setup
    const fs = require('fs');
    const path = require('path');

    async function processToolkit1(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing toolkit 1 file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'toolkit1.txt');
    await processToolkit1(filePath);
