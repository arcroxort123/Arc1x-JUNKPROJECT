const fs = require('fs');
    const path = require('path');

    async function processFile(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'wip.txt');
    await processFile(filePath);
