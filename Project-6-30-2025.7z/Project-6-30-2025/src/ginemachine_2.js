// GeneMachine setup
    const fs = require('fs');
    const path = require('path');

    async function processGeneMachine(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing gene machine file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'gene-machine.txt');
    await processGeneMachine(filePath);

    // Additional GeneMachine functionality can be added here
