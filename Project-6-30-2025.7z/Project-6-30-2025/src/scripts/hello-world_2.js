// HelloWorld Script
    const fs = require('fs');
    const path = require('path');

    async function pushToEndpoint() {
      try {
        const response = await axios.post('http://your-endpoint.com', 'HelloWorld');
        console.log(`Message pushed to endpoint: ${response.data}`);
      } catch (error) {
        console.error('Error pushing message:', error.response ? error.response.data : error.message);
      }
    }

    // Call the function
    pushToEndpoint();
