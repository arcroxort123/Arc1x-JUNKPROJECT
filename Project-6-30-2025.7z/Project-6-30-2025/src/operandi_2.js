// Operandi setup
    const fs = require('fs');
    const path = require('path');

    async function processOperandi(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing operandi file:', error);
      }
    }

    const filePaths = [
      path.resolve(__dirname, '../', 'operandi1.txt'),
      path.resolve(__dirname, '../', 'operandi2.txt'),
      // Add more files as needed
    ];

    for (const filePath of filePaths) {
      await processOperandi(filePath);
    }
