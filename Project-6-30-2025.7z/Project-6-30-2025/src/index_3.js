import { loadDataChunks, processData } from "./src/data-chunks.js";
    import { processMatrixArray } from "./src/matrix-array.js";

    export { loadDataChunks, processData, processMatrixArray };
