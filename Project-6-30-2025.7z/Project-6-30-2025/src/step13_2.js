// Step 13 setup
    const fs = require('fs');
    const path = require('path');

    async function processStep13(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing step 13 file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'step13.txt');
    await processStep13(filePath);

    // Additional Step 13 functionality can be added here
