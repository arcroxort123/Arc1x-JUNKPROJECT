// Atom CartPile setup
    const fs = require('fs');
    const path = require('path');

    async function processCartPile(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing cart pile file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'cartpile.txt');
    await processCartPile(filePath);

    // Additional Atom CartPile functionality can be added here
