// Policy Conditions setup
    const fs = require('fs');
    const path = require('path');

    async function processPolicyConditions(filePath) {
      try {
        const fileContent = await fs.promises.readFile(filePath, 'utf-8');
        console.log(fileContent);
      } catch (error) {
        console.error('Error processing policy conditions file:', error);
      }
    }

    const filePath = path.resolve(__dirname, '../', 'policy-conditions.txt');
    await processPolicyConditions(filePath);
