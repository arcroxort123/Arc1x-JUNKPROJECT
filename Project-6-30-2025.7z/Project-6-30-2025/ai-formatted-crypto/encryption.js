// Encryption Module
    console.log("Encryption: Securing data with AES-256...");
