// Simple project script
    console.log("Arcroxort123 - Work-in-Progress");
