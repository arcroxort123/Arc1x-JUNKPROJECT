## Installation Guide

    ### Prerequisites
    - Node.js v18+
    - Python 3.10+ (required for `pyinstaller`)
    - Vite (for web client)

    ### Steps
    1. Install dependencies:
       ```bash
       npm install
       ```
    2. Run the project:
       ```bash
       node main.js
       ```
