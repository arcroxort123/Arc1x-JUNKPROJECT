// Optional Configurations
    console.log("Optional Configurations: Custom settings for build");
