# Arc1x SuperDistro File Combiner
# Combines 2,813 split files into organized documentation and project structure

param(
    [string]$OutputDir = "docs",
    [string]$CombinedFileName = "combined-documentation.txt",
    [switch]$CreateSubmodules,
    [switch]$Verbose
)

Write-Host "Arc1x SuperDistro Project File Combiner" -ForegroundColor Cyan
Write-Host "=======================================" -ForegroundColor Cyan

# Create output directory if it doesn't exist
if (-not (Test-Path $OutputDir)) {
    New-Item -ItemType Directory -Path $OutputDir -Force | Out-Null
    Write-Host "Created output directory: $OutputDir" -ForegroundColor Green
}

# Get all split files and sort them
$splitFiles = Get-ChildItem -Path "." -Name "split*" | Sort-Object
$totalFiles = $splitFiles.Count

Write-Host "Found $totalFiles split files to process" -ForegroundColor Yellow

# Create the combined output file path
$outputPath = Join-Path (Resolve-Path ".") (Join-Path $OutputDir $CombinedFileName)

Write-Host "Combining files into: $outputPath" -ForegroundColor Yellow

# Initialize progress tracking
$processedFiles = 0
$startTime = Get-Date

# Open output file for writing
$outputStream = [System.IO.StreamWriter]::new($outputPath, $false, [System.Text.Encoding]::UTF8)

try {
    # Write header to combined file
    $outputStream.WriteLine("# Arc1x SuperDistro Combined Documentation")
    $outputStream.WriteLine("# Generated: $(Get-Date)")
    $outputStream.WriteLine("# Total files processed: $totalFiles")
    $outputStream.WriteLine("# Source: Split files from Arc1x SuperDistro project")
    $outputStream.WriteLine("")
    $outputStream.WriteLine("================================================================================")
    $outputStream.WriteLine("")

    foreach ($file in $splitFiles) {
        $processedFiles++
        
        if ($Verbose) {
            Write-Host "Processing: $file ($processedFiles/$totalFiles)" -ForegroundColor Gray
        } else {
            # Show progress every 100 files
            if ($processedFiles % 100 -eq 0) {
                $percentComplete = [math]::Round(($processedFiles / $totalFiles) * 100, 1)
                Write-Host "Progress: $percentComplete% ($processedFiles/$totalFiles files)" -ForegroundColor Yellow
            }
        }
        
        # Write file separator
        $outputStream.WriteLine("--- BEGIN FILE: $file ---")
        
        try {
            # Read and write file content
            $content = Get-Content -Path $file -Raw -ErrorAction Stop
            $outputStream.WriteLine($content)
        }
        catch {
            $outputStream.WriteLine("ERROR: Could not read file $file - $($_.Exception.Message)")
            Write-Warning "Failed to read $file`: $($_.Exception.Message)"
        }
        
        $outputStream.WriteLine("--- END FILE: $file ---")
        $outputStream.WriteLine("")
    }
}
finally {
    $outputStream.Close()
}

$endTime = Get-Date
$duration = $endTime - $startTime

Write-Host "File combination completed!" -ForegroundColor Green
Write-Host "Processed: $processedFiles files" -ForegroundColor Cyan
Write-Host "Duration: $($duration.TotalSeconds) seconds" -ForegroundColor Cyan
Write-Host "Output: $outputPath" -ForegroundColor Cyan

# Create submodule directories if requested
if ($CreateSubmodules) {
    Write-Host "`nCreating submodule directory structure..." -ForegroundColor Yellow
    
    $submodulePaths = @(
        "submodules/core/server-os",
        "submodules/core/virtual-machine", 
        "submodules/core/super-servos",
        "submodules/fabrication/compact-megafab",
        "submodules/fabrication/drone-network",
        "submodules/tools/administration-toolkits",
        "submodules/tools/third-party-vrenv",
        "submodules/advanced/megalink-codedescripts",
        "submodules/advanced/emissionary-vacuum-engine",
        "submodules/advanced/ai-pattern-toy",
        "submodules/advanced/atom-cart-pile",
        "submodules/advanced/pet-hydra-server",
        "components/ai-ecology",
        "components/hyper-milling", 
        "components/crypto-portals",
        "components/cloud-works",
        "components/turbines",
        "config/policies",
        "config/conditions",
        "scripts/build",
        "scripts/deploy",
        "scripts/maintenance"
    )
    
    foreach ($path in $submodulePaths) {
        if (-not (Test-Path $path)) {
            New-Item -ItemType Directory -Path $path -Force | Out-Null
            
            # Create a README.md file for each submodule
            $readmePath = Join-Path $path "README.md"
            $moduleName = Split-Path $path -Leaf
            $moduleCategory = Split-Path (Split-Path $path -Parent) -Leaf
            
            $readmeContent = @"
# $moduleName

## Category: $moduleCategory

## Description
This is the $moduleName module of the Arc1x SuperDistro project.

## Status
Under development - extracted from split file combination.

## Files
- Source files will be organized here based on content analysis
- Documentation will be extracted and structured
- Build configurations will be added as needed

## Usage
Documentation and usage instructions will be added as the module is developed.

## Dependencies
Dependencies will be identified and documented during module organization.
"@
            
            Set-Content -Path $readmePath -Value $readmeContent -Encoding UTF8
        }
    }
    
    Write-Host "Submodule directories created successfully!" -ForegroundColor Green
}

# Generate summary report
$fileSizeKB = [math]::Round((Get-Item $outputPath).Length / 1KB, 2)
Write-Host "`nSummary Report:" -ForegroundColor Cyan
Write-Host "  Combined file size: $fileSizeKB KB" -ForegroundColor White
Write-Host "  Processing rate: $([math]::Round($processedFiles / $duration.TotalSeconds, 1)) files/second" -ForegroundColor White

Write-Host "`nNext steps:" -ForegroundColor Green
Write-Host "1. Review the combined documentation in $outputPath" -ForegroundColor White
Write-Host "2. Use -CreateSubmodules flag to generate directory structure" -ForegroundColor White  
Write-Host "3. Organize content into appropriate submodules" -ForegroundColor White
Write-Host "4. Set up build and deployment scripts" -ForegroundColor White
