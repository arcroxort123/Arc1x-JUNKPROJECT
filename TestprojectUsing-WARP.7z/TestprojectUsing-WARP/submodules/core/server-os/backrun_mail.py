#!/usr/bin/env python3
"""
Arc1x SuperDistro - BackRun Mail System (Step 07)
Following documentation instructions for implementing a quantum-based
telegramable mail system with trip-keyed notes and profile simulation.

Key Features:
- Posted mailbox on grid with trip-keyed notes
- Profile simulator and entry lookup
- Characterized client registration system
- Analog/manual to digital formatter
- Encrypted packet handling with 3-layer permissions
- Quantum-based telegram drafts
- Temporal flux pickup system
"""

import asyncio
import logging
import hashlib
import uuid
import time
import json
import base64
import threading
from typing import Dict, Any, List, Optional, Tuple
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
import tempfile
import secrets
import os

logger = logging.getLogger(__name__)

class MailState(Enum):
    """States for mail processing"""
    PENDING = "pending"
    RECEIVED = "received"
    PROCESSED = "processed"
    ENCRYPTED = "encrypted"
    DELIVERED = "delivered"
    SUSPENDED = "suspended"
    TRIP_KEYED = "trip_keyed"
    DIGITAL_FORMAT = "digital_format"
    ERROR = "error"

class MailType(Enum):
    """Types of mail packets"""
    RESIDENTIAL = "residential"
    BUSINESS = "business"
    HYPERMAIL = "hypermail"
    PILL_DATA = "pill_data"
    VOXEL_MAIL = "voxel_mail"
    QUANTUM_TELEGRAM = "quantum_telegram"
    TEMPORAL_FLUX = "temporal_flux"

class PermissionLayer(Enum):
    """Three-layer permission system"""
    LAYER_1_PACKET = "layer_1_packet"      # Raw received packet
    LAYER_2_PROGRAM = "layer_2_program"    # Transcoded program
    LAYER_3_MAIL = "layer_3_mail"          # Final encrypted mail

@dataclass
class TripKey:
    """Trip key for note authentication"""
    key_id: str
    trip_hash: str
    salt: str
    created_time: float
    expiry_time: float
    
    def is_valid(self) -> bool:
        """Check if trip key is still valid"""
        return time.time() < self.expiry_time
        
    def verify_trip(self, input_text: str) -> bool:
        """Verify trip key against input"""
        test_hash = hashlib.sha256((input_text + self.salt).encode()).hexdigest()
        return test_hash == self.trip_hash

@dataclass 
class MailPacket:
    """Mail packet with full metadata"""
    packet_id: str
    sender_id: str
    recipient_id: str
    mail_type: MailType
    permission_layer: PermissionLayer
    state: MailState
    content: str
    encrypted_content: Optional[str] = None
    trip_key: Optional[TripKey] = None
    timestamp: float = field(default_factory=time.time)
    metadata: Dict[str, Any] = field(default_factory=dict)
    analog_source: bool = False
    quantum_signature: Optional[str] = None
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert to dictionary for serialization"""
        return {
            'packet_id': self.packet_id,
            'sender_id': self.sender_id,
            'recipient_id': self.recipient_id,
            'mail_type': self.mail_type.value,
            'permission_layer': self.permission_layer.value,
            'state': self.state.value,
            'content': self.content,
            'encrypted_content': self.encrypted_content,
            'trip_key': self.trip_key.__dict__ if self.trip_key else None,
            'timestamp': self.timestamp,
            'metadata': self.metadata,
            'analog_source': self.analog_source,
            'quantum_signature': self.quantum_signature
        }

@dataclass
class ClientProfile:
    """Client profile for mail registration"""
    profile_id: str
    client_name: str
    registration_status: str
    trip_keys: List[TripKey] = field(default_factory=list)
    permissions: List[str] = field(default_factory=list)
    mail_address: str = ""
    last_seen: float = field(default_factory=time.time)
    is_characterized: bool = False
    quantum_enabled: bool = False

class AnalogDigitalFormatter:
    """
    Converts analog/manual inputs to digital format
    Handles cases where mail senders can't format properly
    """
    
    def __init__(self, formatter_id: str):
        self.formatter_id = formatter_id
        self.format_rules = {
            'text_patterns': [r'[A-Za-z0-9\s\.\,\!\?\;\:]+'],
            'date_patterns': [r'\d{1,2}\/\d{1,2}\/\d{2,4}', r'\d{4}-\d{2}-\d{2}'],
            'address_patterns': [r'[\w\.-]+@[\w\.-]+\.\w+'],
            'phone_patterns': [r'\d{3}-\d{3}-\d{4}', r'\(\d{3}\)\s?\d{3}-\d{4}']
        }
        logger.info(f"AnalogDigitalFormatter {formatter_id} initialized")
        
    async def format_analog_input(self, raw_input: str, sender_notes: str = "") -> Dict[str, Any]:
        """Format analog/manual input to digital format"""
        logger.info(f"Formatting analog input from raw text")
        
        formatted_data = {
            'original_input': raw_input,
            'formatted_content': raw_input.strip(),
            'detected_patterns': [],
            'formatting_applied': [],
            'sender_notes': sender_notes,
            'format_timestamp': time.time()
        }
        
        # Basic text cleaning
        cleaned_text = raw_input.strip().replace('\n\n', '\n').replace('\t', ' ')
        formatted_data['formatted_content'] = cleaned_text
        formatted_data['formatting_applied'].append('basic_cleaning')
        
        # Pattern detection
        for pattern_type, patterns in self.format_rules.items():
            for pattern in patterns:
                import re
                matches = re.findall(pattern, cleaned_text)
                if matches:
                    formatted_data['detected_patterns'].append({
                        'type': pattern_type,
                        'matches': matches
                    })
                    
        # Auto-format based on detected patterns
        if any(p['type'] == 'address_patterns' for p in formatted_data['detected_patterns']):
            formatted_data['mail_type'] = 'email_format'
            formatted_data['formatting_applied'].append('email_structure')
            
        logger.info(f"Analog formatting complete: {len(formatted_data['detected_patterns'])} patterns detected")
        return formatted_data

class ProfileSimulator:
    """
    Profile simulator and entry lookup system
    Manages client profiles and authentication
    """
    
    def __init__(self, simulator_id: str):
        self.simulator_id = simulator_id
        self.profiles = {}
        self.active_sessions = {}
        self.entry_lookup_cache = {}
        logger.info(f"ProfileSimulator {simulator_id} initialized")
        
    async def create_client_profile(self, client_name: str, permissions: List[str] = None) -> ClientProfile:
        """Create a new client profile"""
        profile_id = f"profile_{hashlib.md5(client_name.encode()).hexdigest()[:8]}"
        
        profile = ClientProfile(
            profile_id=profile_id,
            client_name=client_name,
            registration_status="pending",
            permissions=permissions or ["basic_mail"],
            mail_address=f"{client_name.lower().replace(' ', '_')}@arc1x.local",
            is_characterized=False,
            quantum_enabled=False
        )
        
        self.profiles[profile_id] = profile
        
        logger.info(f"Created client profile: {client_name} ({profile_id})")
        return profile
        
    async def register_client(self, profile_id: str) -> bool:
        """Register a client and mark as characterized"""
        if profile_id not in self.profiles:
            logger.error(f"Profile {profile_id} not found for registration")
            return False
            
        profile = self.profiles[profile_id]
        profile.registration_status = "registered"
        profile.is_characterized = True
        profile.last_seen = time.time()
        
        logger.info(f"Client registered: {profile.client_name}")
        return True
        
    async def lookup_entry(self, search_query: str) -> List[ClientProfile]:
        """Lookup entries by various criteria"""
        logger.info(f"Looking up entries for query: {search_query}")
        
        # Check cache first
        cache_key = hashlib.md5(search_query.encode()).hexdigest()
        if cache_key in self.entry_lookup_cache:
            return self.entry_lookup_cache[cache_key]
            
        results = []
        query_lower = search_query.lower()
        
        for profile in self.profiles.values():
            if (query_lower in profile.client_name.lower() or
                query_lower in profile.mail_address.lower() or
                query_lower in profile.profile_id.lower()):
                results.append(profile)
                
        # Cache results
        self.entry_lookup_cache[cache_key] = results
        
        logger.info(f"Entry lookup found {len(results)} matches")
        return results
        
    async def simulate_profile_interaction(self, profile_id: str, interaction_type: str) -> Dict[str, Any]:
        """Simulate profile interaction for testing"""
        if profile_id not in self.profiles:
            return {'error': 'Profile not found'}
            
        profile = self.profiles[profile_id]
        
        simulation_result = {
            'profile_id': profile_id,
            'interaction_type': interaction_type,
            'timestamp': time.time(),
            'simulation_data': {
                'profile_name': profile.client_name,
                'registration_status': profile.registration_status,
                'permissions': profile.permissions,
                'quantum_enabled': profile.quantum_enabled,
                'last_seen': profile.last_seen
            }
        }
        
        # Update last seen
        profile.last_seen = time.time()
        
        logger.info(f"Profile simulation complete: {interaction_type} for {profile.client_name}")
        return simulation_result

class BackRunMailSystem:
    """
    Main BackRun Mail System implementing Step 07
    Handles quantum-based telegramable mail with trip keys
    """
    
    def __init__(self, mail_system_id: str = "arc1x_backrun_mail"):
        self.mail_system_id = mail_system_id
        self.state = MailState.PENDING
        
        # Initialize components
        self.formatter = AnalogDigitalFormatter(f"{mail_system_id}_formatter")
        self.profile_sim = ProfileSimulator(f"{mail_system_id}_profiles")
        
        # Mail storage
        self.mailboxes = {}  # Grid-based mailboxes
        self.mail_packets = {}
        self.trip_keys = {}
        
        # System configuration
        self.mail_root = Path(tempfile.gettempdir()) / "arc1x_backrun_mail"
        self.mail_root.mkdir(exist_ok=True)
        
        # Three-layer permission system
        self.layer_processors = {
            PermissionLayer.LAYER_1_PACKET: self._process_layer_1_packet,
            PermissionLayer.LAYER_2_PROGRAM: self._process_layer_2_program,
            PermissionLayer.LAYER_3_MAIL: self._process_layer_3_mail
        }
        
        # Statistics
        self.packets_processed = 0
        self.trip_keys_generated = 0
        self.quantum_telegrams_sent = 0
        
        logger.info(f"BackRunMailSystem {mail_system_id} initialized")
        logger.info(f"Mail root: {self.mail_root}")
        
    async def generate_trip_key(self, client_id: str, note_content: str) -> TripKey:
        """Generate a trip key for note authentication"""
        salt = secrets.token_hex(16)
        key_id = f"trip_{hashlib.md5((client_id + str(time.time())).encode()).hexdigest()[:8]}"
        
        # Create trip hash
        trip_input = f"{note_content}_{client_id}_{salt}"
        trip_hash = hashlib.sha256(trip_input.encode()).hexdigest()
        
        trip_key = TripKey(
            key_id=key_id,
            trip_hash=trip_hash,
            salt=salt,
            created_time=time.time(),
            expiry_time=time.time() + (24 * 60 * 60)  # 24 hours
        )
        
        self.trip_keys[key_id] = trip_key
        self.trip_keys_generated += 1
        
        logger.info(f"Generated trip key {key_id} for client {client_id}")
        return trip_key
        
    async def create_mailbox(self, mailbox_id: str, owner_profile_id: str) -> Dict[str, Any]:
        """Create a posted mailbox on grid"""
        mailbox_data = {
            'mailbox_id': mailbox_id,
            'owner_profile_id': owner_profile_id,
            'grid_position': f"grid_{len(self.mailboxes) + 1}",
            'created_time': time.time(),
            'mail_queue': [],
            'trip_key_required': True,
            'analog_formatter_enabled': True,
            'quantum_capable': True
        }
        
        self.mailboxes[mailbox_id] = mailbox_data
        
        # Create mailbox directory
        mailbox_dir = self.mail_root / mailbox_id
        mailbox_dir.mkdir(exist_ok=True)
        
        logger.info(f"Created mailbox {mailbox_id} at position {mailbox_data['grid_position']}")
        return mailbox_data
        
    async def send_mail_packet(self, sender_id: str, recipient_id: str, content: str, 
                              mail_type: MailType = MailType.RESIDENTIAL,
                              analog_input: bool = False) -> MailPacket:
        """Send a mail packet through the system"""
        packet_id = f"packet_{uuid.uuid4().hex[:12]}"
        
        # Process analog input if needed
        if analog_input:
            formatted_data = await self.formatter.format_analog_input(content, f"From: {sender_id}")
            content = formatted_data['formatted_content']
            
        # Create mail packet
        packet = MailPacket(
            packet_id=packet_id,
            sender_id=sender_id,
            recipient_id=recipient_id,
            mail_type=mail_type,
            permission_layer=PermissionLayer.LAYER_1_PACKET,
            state=MailState.RECEIVED,
            content=content,
            analog_source=analog_input
        )
        
        # Generate trip key for the packet
        trip_key = await self.generate_trip_key(sender_id, content[:100])  # First 100 chars
        packet.trip_key = trip_key
        packet.state = MailState.TRIP_KEYED
        
        self.mail_packets[packet_id] = packet
        self.packets_processed += 1
        
        logger.info(f"Mail packet sent: {packet_id} from {sender_id} to {recipient_id}")
        
        # Process through three-layer system
        await self._process_mail_layers(packet)
        
        return packet
        
    async def _process_mail_layers(self, packet: MailPacket):
        """Process mail through three-layer permission system"""
        logger.info(f"Processing mail packet {packet.packet_id} through layer system")
        
        # Layer 1: Raw received packet
        packet.permission_layer = PermissionLayer.LAYER_1_PACKET
        await self.layer_processors[PermissionLayer.LAYER_1_PACKET](packet)
        
        # Layer 2: Generated program/transcoded
        packet.permission_layer = PermissionLayer.LAYER_2_PROGRAM  
        await self.layer_processors[PermissionLayer.LAYER_2_PROGRAM](packet)
        
        # Layer 3: Final encrypted mail
        packet.permission_layer = PermissionLayer.LAYER_3_MAIL
        await self.layer_processors[PermissionLayer.LAYER_3_MAIL](packet)
        
        packet.state = MailState.DELIVERED
        logger.info(f"Mail packet {packet.packet_id} processed through all layers")
        
    async def _process_layer_1_packet(self, packet: MailPacket):
        """Process Layer 1: Raw received packet"""
        logger.debug(f"Processing Layer 1 for packet {packet.packet_id}")
        
        # Store raw packet data
        packet.metadata['layer_1_processing'] = {
            'received_time': time.time(),
            'raw_size': len(packet.content),
            'analog_source': packet.analog_source,
            'trip_key_verified': packet.trip_key is not None and packet.trip_key.is_valid()
        }
        
        packet.state = MailState.PROCESSED
        
    async def _process_layer_2_program(self, packet: MailPacket):
        """Process Layer 2: Generated program that transcodes packet"""
        logger.debug(f"Processing Layer 2 for packet {packet.packet_id}")
        
        # Simulate program that processes the mail
        program_output = {
            'transcoded_content': base64.b64encode(packet.content.encode()).decode(),
            'program_metadata': {
                'transcoding_time': time.time(),
                'encoding': 'base64',
                'suspended_state_capable': True
            }
        }
        
        packet.metadata['layer_2_processing'] = program_output
        
    async def _process_layer_3_mail(self, packet: MailPacket):
        """Process Layer 3: Final encrypted mail product"""
        logger.debug(f"Processing Layer 3 for packet {packet.packet_id}")
        
        # Encrypt the final mail content
        encrypted_content = await self._encrypt_mail_content(packet.content, packet.sender_id)
        packet.encrypted_content = encrypted_content
        
        # Create final mail metadata
        packet.metadata['layer_3_processing'] = {
            'encryption_time': time.time(),
            'encryption_method': 'arc1x_mail_encryption',
            'quantum_signature': await self._generate_quantum_signature(packet),
            'suspended_state': True,
            'inbox_ready': True
        }
        
        packet.quantum_signature = packet.metadata['layer_3_processing']['quantum_signature']
        packet.state = MailState.ENCRYPTED
        
    async def _encrypt_mail_content(self, content: str, sender_id: str) -> str:
        """Encrypt mail content for final delivery"""
        # Simple encryption simulation
        encryption_key = hashlib.sha256(f"{sender_id}_arc1x_mail_key".encode()).hexdigest()
        encrypted = base64.b64encode(f"{encryption_key[:16]}{content}".encode()).decode()
        return encrypted
        
    async def _generate_quantum_signature(self, packet: MailPacket) -> str:
        """Generate quantum signature for mail packet"""
        signature_data = f"{packet.packet_id}{packet.sender_id}{packet.timestamp}"
        quantum_signature = hashlib.sha256(signature_data.encode()).hexdigest()[:32]
        return f"quantum_{quantum_signature}"
        
    async def send_quantum_telegram(self, sender_id: str, recipient_id: str, 
                                  telegram_content: str) -> Dict[str, Any]:
        """Send quantum-based telegram with temporal flux"""
        logger.info(f"Sending quantum telegram from {sender_id} to {recipient_id}")
        
        # Create quantum telegram packet
        telegram_id = f"qtelegram_{uuid.uuid4().hex[:10]}"
        
        # Generate temporal flux signature
        temporal_flux = {
            'flux_id': f"flux_{time.time()}_{secrets.token_hex(8)}",
            'temporal_pickup_time': time.time() + 1.0,  # 1 second delay
            'flux_signature': hashlib.sha256(f"{telegram_content}{time.time()}".encode()).hexdigest(),
            'multisocket_enabled': True,
            'ballistic_ignitor_status': 'active'
        }
        
        quantum_telegram = {
            'telegram_id': telegram_id,
            'sender_id': sender_id,
            'recipient_id': recipient_id,
            'content': telegram_content,
            'temporal_flux': temporal_flux,
            'quantum_state': 'entangled',
            'delivery_method': 'quantum_teleportation',
            'timestamp': time.time()
        }
        
        # Store telegram
        telegram_file = self.mail_root / f"{telegram_id}.quantum"
        with open(telegram_file, 'w') as f:
            json.dump(quantum_telegram, f, indent=2)
            
        self.quantum_telegrams_sent += 1
        
        logger.info(f"Quantum telegram {telegram_id} sent with temporal flux {temporal_flux['flux_id']}")
        return quantum_telegram
        
    async def retrieve_mail(self, mailbox_id: str, trip_key_input: str = None) -> List[MailPacket]:
        """Retrieve mail from mailbox with trip key verification"""
        if mailbox_id not in self.mailboxes:
            logger.error(f"Mailbox {mailbox_id} not found")
            return []
            
        mailbox = self.mailboxes[mailbox_id]
        retrieved_mail = []
        
        for packet_id in mailbox['mail_queue']:
            if packet_id in self.mail_packets:
                packet = self.mail_packets[packet_id]
                
                # Verify trip key if required
                if mailbox['trip_key_required'] and packet.trip_key:
                    if trip_key_input and packet.trip_key.verify_trip(trip_key_input):
                        retrieved_mail.append(packet)
                        logger.info(f"Mail retrieved with valid trip key: {packet_id}")
                    else:
                        logger.warning(f"Invalid trip key for packet {packet_id}")
                else:
                    retrieved_mail.append(packet)
                    
        logger.info(f"Retrieved {len(retrieved_mail)} mail packets from mailbox {mailbox_id}")
        return retrieved_mail
        
    async def get_mail_statistics(self) -> Dict[str, Any]:
        """Get comprehensive mail system statistics"""
        return {
            'mail_system_id': self.mail_system_id,
            'current_state': self.state.value,
            'mail_statistics': {
                'packets_processed': self.packets_processed,
                'trip_keys_generated': self.trip_keys_generated,
                'quantum_telegrams_sent': self.quantum_telegrams_sent,
                'active_mailboxes': len(self.mailboxes),
                'total_mail_packets': len(self.mail_packets)
            },
            'mailbox_grid': {
                box_id: {
                    'position': box_data['grid_position'],
                    'queue_size': len(box_data['mail_queue']),
                    'quantum_capable': box_data['quantum_capable']
                }
                for box_id, box_data in self.mailboxes.items()
            },
            'layer_processing': {
                'layer_1_packets': sum(1 for p in self.mail_packets.values() 
                                     if 'layer_1_processing' in p.metadata),
                'layer_2_programs': sum(1 for p in self.mail_packets.values() 
                                      if 'layer_2_processing' in p.metadata),
                'layer_3_encrypted': sum(1 for p in self.mail_packets.values() 
                                       if 'layer_3_processing' in p.metadata)
            },
            'client_profiles': len(self.profile_sim.profiles),
            'trip_key_stats': {
                'total_generated': len(self.trip_keys),
                'valid_keys': sum(1 for tk in self.trip_keys.values() if tk.is_valid()),
                'expired_keys': sum(1 for tk in self.trip_keys.values() if not tk.is_valid())
            }
        }
        
    async def shutdown(self):
        """Shutdown backrun mail system"""
        logger.info(f"Shutting down BackRunMailSystem {self.mail_system_id}")
        
        # Clear active sessions
        self.profile_sim.active_sessions.clear()
        
        # Update all profiles last seen
        for profile in self.profile_sim.profiles.values():
            profile.last_seen = time.time()
            
        self.state = MailState.PENDING
        logger.info("BackRunMailSystem shutdown complete")

# Example usage and testing
async def main():
    """Demonstrate BackRun Mail System capabilities"""
    logger.info("Starting Arc1x BackRun Mail System - Step 07 Implementation")
    
    # Create backrun mail system
    mail_system = BackRunMailSystem("arc1x_step07_backrun_mail")
    
    # Create client profiles
    logger.info("\n=== Creating Client Profiles ===")
    alice_profile = await mail_system.profile_sim.create_client_profile(
        "Alice Smith", ["basic_mail", "quantum_mail"]
    )
    await mail_system.profile_sim.register_client(alice_profile.profile_id)
    
    bob_profile = await mail_system.profile_sim.create_client_profile(
        "Bob Johnson", ["basic_mail", "analog_mail"]
    )
    await mail_system.profile_sim.register_client(bob_profile.profile_id)
    
    charlie_profile = await mail_system.profile_sim.create_client_profile(
        "Charlie Wilson", ["quantum_mail", "telegram_mail"]
    )
    await mail_system.profile_sim.register_client(charlie_profile.profile_id)
    
    # Create mailboxes
    logger.info("\n=== Creating Mailboxes on Grid ===")
    alice_mailbox = await mail_system.create_mailbox("mailbox_alice", alice_profile.profile_id)
    bob_mailbox = await mail_system.create_mailbox("mailbox_bob", bob_profile.profile_id)
    charlie_mailbox = await mail_system.create_mailbox("mailbox_charlie", charlie_profile.profile_id)
    
    # Test regular mail sending
    logger.info("\n=== Testing Regular Mail System ===")
    
    # Send digital mail
    digital_mail = await mail_system.send_mail_packet(
        alice_profile.profile_id,
        bob_profile.profile_id,
        "Hello Bob! This is a test message from Alice.",
        MailType.RESIDENTIAL
    )
    
    # Add to Bob's mailbox
    mail_system.mailboxes["mailbox_bob"]["mail_queue"].append(digital_mail.packet_id)
    
    # Send analog mail (manual input)
    analog_content = """
    Dear Charlie,
    
    I hope this message finds you well.
    Please call me at 555-123-4567.
    
    Best regards,
    Alice Smith
    alice@example.com
    """
    
    analog_mail = await mail_system.send_mail_packet(
        alice_profile.profile_id,
        charlie_profile.profile_id,
        analog_content,
        MailType.BUSINESS,
        analog_input=True
    )
    
    # Add to Charlie's mailbox
    mail_system.mailboxes["mailbox_charlie"]["mail_queue"].append(analog_mail.packet_id)
    
    # Test quantum telegram
    logger.info("\n=== Testing Quantum Telegram System ===")
    
    quantum_telegram = await mail_system.send_quantum_telegram(
        charlie_profile.profile_id,
        alice_profile.profile_id,
        "URGENT: Quantum entanglement test successful. Temporal flux detected at coordinates 127.0.0.1:8080."
    )
    
    # Test profile simulation
    logger.info("\n=== Testing Profile Simulation ===")
    
    alice_simulation = await mail_system.profile_sim.simulate_profile_interaction(
        alice_profile.profile_id, "mail_check"
    )
    
    # Test entry lookup
    lookup_results = await mail_system.profile_sim.lookup_entry("alice")
    logger.info(f"Entry lookup for 'alice' found {len(lookup_results)} results")
    
    # Test mail retrieval with trip keys
    logger.info("\n=== Testing Mail Retrieval with Trip Keys ===")
    
    # Get trip key for digital mail
    if digital_mail.trip_key:
        trip_key_input = f"Hello Bob! This is a test message from Alice._{alice_profile.profile_id}_{digital_mail.trip_key.salt}"
        retrieved_mail = await mail_system.retrieve_mail("mailbox_bob", trip_key_input)
        logger.info(f"Retrieved {len(retrieved_mail)} mail packets from Bob's mailbox")
        
        if retrieved_mail:
            mail = retrieved_mail[0]
            logger.info(f"Retrieved mail content: {mail.content[:50]}...")
            logger.info(f"Mail processing layers: {list(mail.metadata.keys())}")
    
    # Test hypermail (out of region)
    logger.info("\n=== Testing HyperMail System ===")
    
    hypermail = await mail_system.send_mail_packet(
        "external_sender@remote.system",
        alice_profile.profile_id,
        "This is hypermail from outside the region limits.",
        MailType.HYPERMAIL
    )
    
    # Display comprehensive statistics
    stats = await mail_system.get_mail_statistics()
    logger.info("\n=== BackRun Mail System Statistics ===")
    logger.info(f"System ID: {stats['mail_system_id']}")
    logger.info(f"Current state: {stats['current_state']}")
    
    mail_stats = stats['mail_statistics']
    logger.info(f"Packets processed: {mail_stats['packets_processed']}")
    logger.info(f"Trip keys generated: {mail_stats['trip_keys_generated']}")
    logger.info(f"Quantum telegrams sent: {mail_stats['quantum_telegrams_sent']}")
    logger.info(f"Active mailboxes: {mail_stats['active_mailboxes']}")
    
    logger.info(f"\nMailbox grid positions:")
    for box_id, box_info in stats['mailbox_grid'].items():
        logger.info(f"  {box_id}: {box_info['position']} (queue: {box_info['queue_size']}, quantum: {box_info['quantum_capable']})")
        
    layer_stats = stats['layer_processing']
    logger.info(f"\nLayer processing:")
    logger.info(f"  Layer 1 packets: {layer_stats['layer_1_packets']}")
    logger.info(f"  Layer 2 programs: {layer_stats['layer_2_programs']}")
    logger.info(f"  Layer 3 encrypted: {layer_stats['layer_3_encrypted']}")
    
    trip_key_stats = stats['trip_key_stats']
    logger.info(f"\nTrip key statistics:")
    logger.info(f"  Total generated: {trip_key_stats['total_generated']}")
    logger.info(f"  Valid keys: {trip_key_stats['valid_keys']}")
    logger.info(f"  Expired keys: {trip_key_stats['expired_keys']}")
    
    logger.info(f"\nClient profiles: {stats['client_profiles']}")
    
    # Shutdown
    await mail_system.shutdown()
    
    logger.info("BackRun Mail System Step 07 demonstration completed")

if __name__ == "__main__":
    # Configure logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(levelname)s - %(message)s'
    )
    
    asyncio.run(main())
